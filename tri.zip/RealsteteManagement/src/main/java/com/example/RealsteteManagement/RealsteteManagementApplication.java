package com.example.RealsteteManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RealsteteManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(RealsteteManagementApplication.class, args);
	}

}
