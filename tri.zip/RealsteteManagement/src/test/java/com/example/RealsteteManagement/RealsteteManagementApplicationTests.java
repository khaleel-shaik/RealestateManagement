package com.example.RealsteteManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealsteteManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
